This code of 3 parts is built in Google Colab.

To execute the code you have to :
	Either download the images by running the cell with !wget commands.

	Or upload the folder:'detectron2_inputs' to your google drive and mount the drive on colab.
